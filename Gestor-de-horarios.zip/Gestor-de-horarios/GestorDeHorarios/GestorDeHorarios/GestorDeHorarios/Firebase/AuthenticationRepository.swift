
import Foundation
import FirebaseAuth
import FirebaseFirestore

final class AuthenticationRepository {
    private let authenticationFirebaseDatasource: AuthenticationFirebaseDatasource
    private let firestoreDatasource: FirestoreDatasource
    
    init(
        authenticationFirebaseDatasource: AuthenticationFirebaseDatasource = AuthenticationFirebaseDatasource(),
        firestoreDatasource: FirestoreDatasource = FirestoreDatasource()
    ) {
        self.authenticationFirebaseDatasource = authenticationFirebaseDatasource
        self.firestoreDatasource = firestoreDatasource
    }
    
    // Métodos de autenticación
    func getCurrentUser() -> User? {
        authenticationFirebaseDatasource.getCurrentUser()
    }
    
    func createNewUser(email: String, password: String, completionBlock: @escaping (Result<User, Error>) -> Void) {
        authenticationFirebaseDatasource.createNewUser(email: email, password: password) { [weak self] result in
            switch result {
            case .success(let user):
                // Crear el documento del usuario en Firestore
                if let userId = Auth.auth().currentUser?.uid {
                    self?.firestoreDatasource.createUserDocument(userId: userId, email: email) { error in
                        if let error = error {
                            completionBlock(.failure(error))
                        } else {
                            completionBlock(.success(user))
                        }
                    }
                } else {
                    completionBlock(.failure(NSError(domain: "FirestoreError", code: -1, userInfo: [NSLocalizedDescriptionKey: "No se pudo obtener el UID del usuario"])))
                }
            case .failure(let error):
                completionBlock(.failure(error))
            }
        }
    }
    
    func login(email: String, password: String, completionBlock: @escaping (Result<User, Error>) -> Void) {
        authenticationFirebaseDatasource.login(email: email, password: password, completionBlock: completionBlock)
    }
    
    func logout() throws {
        try authenticationFirebaseDatasource.logout()
    }
    
    // Métodos de Firestore
    func updateUserField(userId: String, field: String, value: Any, completion: @escaping (Error?) -> Void) {
        firestoreDatasource.updateUserDocument(userId: userId, newField: field, value: value, completion: completion)
    }
    
    func fetchUserData(userId: String, completion: @escaping ([String: Any]?, Error?) -> Void) {
        firestoreDatasource.fetchUserDocument(userId: userId, completion: completion)
    }
    
    // Nuevos métodos para manejar horarios
    func addHorario(userId: String, horario: [String: Any], completion: @escaping (Error?) -> Void) {
        firestoreDatasource.addHorario(userId: userId, horario: horario, completion: completion)
    }
    
    func fetchHorarios(userId: String, completion: @escaping ([[String: Any]]?, Error?) -> Void) {
        firestoreDatasource.fetchHorarios(userId: userId, completion: completion)
    }
}
