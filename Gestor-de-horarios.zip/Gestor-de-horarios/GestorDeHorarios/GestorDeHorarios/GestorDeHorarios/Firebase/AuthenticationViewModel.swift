import Foundation
import FirebaseAuth
import FirebaseFirestore

final class AuthenticationViewModel: ObservableObject {
    @Published var user: User?
    @Published var messageError: String?
    private let authenticationRepository: AuthenticationRepository
    
    init(authenticationRepository: AuthenticationRepository = AuthenticationRepository()) {
        self.authenticationRepository = authenticationRepository
    }
    
    // Obtener el usuario actual
    func getCurrentUser() {
        self.user = authenticationRepository.getCurrentUser()
    }
    
    // Crear un nuevo usuario y guardar sus datos en Firestore
    func createNewUser(email: String, password: String) {
        authenticationRepository.createNewUser(email: email, password: password) { [weak self] result in
            switch result {
            case .success(let user):
                self?.user = user
            case .failure(let error):
                self?.messageError = error.localizedDescription
            }
        }
    }
    
    // Iniciar sesión
    func login(email: String, password: String) {
        authenticationRepository.login(email: email, password: password) { [weak self] result in
            switch result {
            case .success(let user):
                self?.user = user
                self?.messageError = nil // Limpiar el mensaje de error
            case .failure(let error):
                switch error {
                case AuthErrorCode.invalidEmail:
                    self?.messageError = "El correo electrónico no es válido."
                case AuthErrorCode.wrongPassword:
                    self?.messageError = "La contraseña es incorrecta."
                case AuthErrorCode.userNotFound:
                    self?.messageError = "El usuario no existe."
                default:
                    self?.messageError = "Ocurrió un error. Por favor, inténtalo de nuevo."
                }
            }
        }
    }
    
    // Cerrar sesión
    func logout() {
        do {
            try authenticationRepository.logout()
            self.user = nil
            NotificationCenter.default.post(name: .userDidLogout, object: nil)
        } catch {
            print("Error al cerrar sesión: \(error.localizedDescription)")
        }
    }
    
    // Enviar correo de restablecimiento de contraseña
    func sendPasswordReset(email: String) {
        Auth.auth().sendPasswordReset(withEmail: email) { [weak self] error in
            if let error = error {
                self?.messageError = error.localizedDescription
            } else {
                self?.messageError = "Se ha enviado un correo electrónico para restablecer tu contraseña."
            }
        }
    }
    
    // Actualizar un campo en Firestore
    func updateUserField(userId: String, field: String, value: Any) {
        authenticationRepository.updateUserField(userId: userId, field: field, value: value) { [weak self] error in
            if let error = error {
                self?.messageError = error.localizedDescription
            } else {
                print("Campo actualizado correctamente")
            }
        }
    }
    
    // Agregar un horario
    func addHorario(userId: String, horario: [String: Any], completion: @escaping (Error?) -> Void) {
        authenticationRepository.addHorario(userId: userId, horario: horario, completion: completion)
    }
    
    // Obtener horarios del usuario
    func fetchHorarios(userId: String, completion: @escaping ([[String: Any]]?, Error?) -> Void) {
        authenticationRepository.fetchHorarios(userId: userId, completion: completion)
    }
    
    // Obtener datos del usuario desde Firestore
    func fetchUserData(userId: String) {
        authenticationRepository.fetchUserData(userId: userId) { [weak self] data, error in
            if let error = error {
                self?.messageError = error.localizedDescription
            } else if let data = data {
                print("Datos del usuario: \(data)")
            }
        }
    }
}
