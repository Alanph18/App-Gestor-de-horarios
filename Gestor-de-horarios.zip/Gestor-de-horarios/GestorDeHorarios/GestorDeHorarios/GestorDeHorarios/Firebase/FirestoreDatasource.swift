//
import FirebaseFirestore

final class FirestoreDatasource {
    private let db = Firestore.firestore()

    // Crear un documento para un usuario
    func createUserDocument(userId: String, email: String, completion: @escaping (Error?) -> Void) {
        let userData: [String: Any] = [
            "email": email,
            "fechaRegistro": Timestamp(date: Date())
        ]
        
        db.collection("usuarios").document(userId).setData(userData) { error in
            completion(error)
        }
    }

    // Actualizar un documento existente
    func updateUserDocument(userId: String, newField: String, value: Any, completion: @escaping (Error?) -> Void) {
        db.collection("usuarios").document(userId).updateData([newField: value]) { error in
            completion(error)
        }
    }

    // Obtener datos de un usuario
    func fetchUserDocument(userId: String, completion: @escaping ([String: Any]?, Error?) -> Void) {
        db.collection("usuarios").document(userId).getDocument { document, error in
            if let document = document, document.exists {
                completion(document.data(), nil)
            } else {
                completion(nil, error)
            }
        }
    }

    // Agregar un horario
    func addHorario(userId: String, horario: [String: Any], completion: @escaping (Error?) -> Void) {
        db.collection("usuarios").document(userId).collection("horarios").addDocument(data: horario) { error in
            completion(error)
        }
    }

    // Obtener horarios del usuario
    func fetchHorarios(userId: String, completion: @escaping ([[String: Any]]?, Error?) -> Void) {
        db.collection("usuarios").document(userId).collection("horarios").getDocuments { snapshot, error in
            if let error = error {
                completion(nil, error)
            } else {
                let horarios = snapshot?.documents.compactMap { $0.data() } ?? []
                completion(horarios, nil)
            }
        }
    }
}
